#import <Foundation/Foundation.h>
#include <time.h>
#include <stdlib.h>

void selectionSort(NSMutableArray *arr);

void insertionSort(NSMutableArray *arr);

void heapSort(NSMutableArray *arr);

void quickSort(NSMutableArray *arr);

void mergeSort(NSMutableArray *arr);

void bubbleSort(NSMutableArray *arr);
